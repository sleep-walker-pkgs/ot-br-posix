/*
 *  Copyright (c) 2017-2021, The OpenThread Authors.
 *  All rights reserved.
 *
 *  Redistribution and use in source and binary forms, with or without
 *  modification, are permitted provided that the following conditions are met:
 *  1. Redistributions of source code must retain the above copyright
 *     notice, this list of conditions and the following disclaimer.
 *  2. Redistributions in binary form must reproduce the above copyright
 *     notice, this list of conditions and the following disclaimer in the
 *     documentation and/or other materials provided with the distribution.
 *  3. Neither the name of the copyright holder nor the
 *     names of its contributors may be used to endorse or promote products
 *     derived from this software without specific prior written permission.
 *
 *  THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 *  AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 *  IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 *  ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE
 *  LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR
 *  CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
 *  SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS
 *  INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN
 *  CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
 *  ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
 *  POSSIBILITY OF SUCH DAMAGE.
 */

/**
 * @file
 * This file includes definition for DNS utilities.
 */

#ifndef OTBR_UTILS_DNS_UTILS_HPP_
#define OTBR_UTILS_DNS_UTILS_HPP_

#include "openthread-br/config.h"

#include <string>

#include "common/types.hpp"

namespace otbr {

namespace DnsUtils {

/**
 * This structure represents DNS Name information.
 *
 * @sa SplitFullDnsName
 */
struct DnsNameInfo
{
    std::string mInstanceName; ///< Instance name, or empty if the DNS name is not a service instance.
    std::string mServiceName;  ///< Service name, or empty if the DNS name is not a service or service instance.
    std::string mHostName;     ///< Host name, or empty if the DNS name is not a host name.
    std::string mDomain;       ///< Domain name.

    /**
     * This method returns if the DNS name is a service instance.
     *
     * @returns Whether the DNS name is a service instance.
     */
    bool IsServiceInstance(void) const { return !mInstanceName.empty(); };

    /**
     * This method returns if the DNS name is a service.
     *
     * @returns Whether the DNS name is a service.
     */
    bool IsService(void) const { return !mServiceName.empty() && mInstanceName.empty(); }

    /**
     * This method returns if the DNS name is a host.
     *
     * @returns Whether the DNS name is a host.
     */
    bool IsHost(void) const { return mServiceName.empty(); }
};

/**
 * This method splits a full DNS name into name components.
 *
 * @param[in] aName  The full DNS name to dissect.
 *
 * @returns A `DnsNameInfo` structure containing DNS name information.
 *
 * @sa DnsNameInfo
 */
DnsNameInfo SplitFullDnsName(const std::string &aName);

/**
 * This function splits a full service name into components.
 *
 * @param[in]  aFullName  The full service name to split.
 * @param[out] aType      A reference to a string to receive the service type.
 * @param[out] aDomain    A reference to a string to receive the domain.
 *
 * @retval OTBR_ERROR_NONE          Successfully split the full service name.
 * @retval OTBR_ERROR_INVALID_ARGS  If the full service name is not valid.
 */
otbrError SplitFullServiceName(const std::string &aFullName, std::string &aType, std::string &aDomain);

/**
 * This function splits a full service instance name into components.
 *
 * @param[in]  aFullName      The full service instance name to split.
 * @param[out] aInstanceName  A reference to a string to receive the instance name.
 * @param[out] aType          A reference to a string to receive the service type.
 * @param[out] aDomain        A reference to a string to receive the domain.
 *
 * @retval OTBR_ERROR_NONE          Successfully split the full service instance name.
 * @retval OTBR_ERROR_INVALID_ARGS  If the full service instance name is not valid.
 */
otbrError SplitFullServiceInstanceName(const std::string &aFullName,
                                       std::string       &aInstanceName,
                                       std::string       &aType,
                                       std::string       &aDomain);

/**
 * This function splits a full host name into components.
 *
 * @param[in]  aFullName  The full host name to split.
 * @param[out] aHostName  A reference to a string to receive the host name.
 * @param[out] aDomain    A reference to a string to receive the domain.
 *
 * @retval OTBR_ERROR_NONE          Successfully split the full host name.
 * @retval OTBR_ERROR_INVALID_ARGS  If the full host name is not valid.
 */
otbrError SplitFullHostName(const std::string &aFullName, std::string &aHostName, std::string &aDomain);

/**
 * This function unescapes a DNS Service Instance name according to "DNS Name Escaping".
 *
 * @sa  "Notes on DNS Name Escaping" at
 *      https://opensource.apple.com/source/mDNSResponder/mDNSResponder-1310.140.1/mDNSShared/dns_sd.h.auto.html.
 *
 * @param[in] aName  The DNS Service Instance name to unescape.
 *
 * @returns  The unescaped DNS Service Instance name.
 */
std::string UnescapeInstanceName(const std::string &aName);

/**
 * This function checks a given host name for sanity.
 *
 * Check criteria:
 *      The host name must ends with dot.
 *
 * @param[in] aHostName  The host name to check.
 *
 * @retval OTBR_ERROR_NONE          The host name is valid.
 * @retval OTBR_ERROR_INVALID_ARGS  The host name is invalid.
 */
otbrError CheckHostnameSanity(const std::string &aHostName);

/**
 * This function checks a given service name for sanity.
 *
 * Check criteria:
 *      The service name must contain at least one dot.
 *      The service name must not end with dot.
 *
 * @param[in] aServiceName  The service name to check.
 *
 * @retval OTBR_ERROR_NONE          The service name is valid.
 * @retval OTBR_ERROR_INVALID_ARGS  The service name is invalid.
 */
otbrError CheckServiceNameSanity(const std::string &aServiceName);

} // namespace DnsUtils
} // namespace otbr
#endif // OTBR_UTILS_DNS_UTILS_HPP_
