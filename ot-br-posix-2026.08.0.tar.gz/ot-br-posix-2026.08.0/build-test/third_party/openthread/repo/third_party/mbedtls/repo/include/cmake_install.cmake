# Install script for directory: /tmp/pkgbuild/ot-br-posix-2026.08.0/third_party/openthread/repo/third_party/mbedtls/repo/include

# Set the install prefix
if(NOT DEFINED CMAKE_INSTALL_PREFIX)
  set(CMAKE_INSTALL_PREFIX "/usr/local")
endif()
string(REGEX REPLACE "/$" "" CMAKE_INSTALL_PREFIX "${CMAKE_INSTALL_PREFIX}")

# Set the install configuration name.
if(NOT DEFINED CMAKE_INSTALL_CONFIG_NAME)
  if(BUILD_TYPE)
    string(REGEX REPLACE "^[^A-Za-z0-9_]+" ""
           CMAKE_INSTALL_CONFIG_NAME "${BUILD_TYPE}")
  else()
    set(CMAKE_INSTALL_CONFIG_NAME "Release")
  endif()
  message(STATUS "Install configuration: \"${CMAKE_INSTALL_CONFIG_NAME}\"")
endif()

# Set the component getting installed.
if(NOT CMAKE_INSTALL_COMPONENT)
  if(COMPONENT)
    message(STATUS "Install component: \"${COMPONENT}\"")
    set(CMAKE_INSTALL_COMPONENT "${COMPONENT}")
  else()
    set(CMAKE_INSTALL_COMPONENT)
  endif()
endif()

# Install shared libraries without execute permission?
if(NOT DEFINED CMAKE_INSTALL_SO_NO_EXE)
  set(CMAKE_INSTALL_SO_NO_EXE "0")
endif()

# Is this installation the result of a crosscompile?
if(NOT DEFINED CMAKE_CROSSCOMPILING)
  set(CMAKE_CROSSCOMPILING "FALSE")
endif()

# Set path to fallback-tool for dependency-resolution.
if(NOT DEFINED CMAKE_OBJDUMP)
  set(CMAKE_OBJDUMP "/usr/bin/objdump")
endif()

if(CMAKE_INSTALL_COMPONENT STREQUAL "Unspecified" OR NOT CMAKE_INSTALL_COMPONENT)
  file(INSTALL DESTINATION "${CMAKE_INSTALL_PREFIX}/include/mbedtls" TYPE FILE PERMISSIONS OWNER_READ OWNER_WRITE GROUP_READ WORLD_READ FILES
    "/tmp/pkgbuild/ot-br-posix-2026.08.0/third_party/openthread/repo/third_party/mbedtls/repo/include/mbedtls/aes.h"
    "/tmp/pkgbuild/ot-br-posix-2026.08.0/third_party/openthread/repo/third_party/mbedtls/repo/include/mbedtls/aria.h"
    "/tmp/pkgbuild/ot-br-posix-2026.08.0/third_party/openthread/repo/third_party/mbedtls/repo/include/mbedtls/asn1.h"
    "/tmp/pkgbuild/ot-br-posix-2026.08.0/third_party/openthread/repo/third_party/mbedtls/repo/include/mbedtls/asn1write.h"
    "/tmp/pkgbuild/ot-br-posix-2026.08.0/third_party/openthread/repo/third_party/mbedtls/repo/include/mbedtls/base64.h"
    "/tmp/pkgbuild/ot-br-posix-2026.08.0/third_party/openthread/repo/third_party/mbedtls/repo/include/mbedtls/bignum.h"
    "/tmp/pkgbuild/ot-br-posix-2026.08.0/third_party/openthread/repo/third_party/mbedtls/repo/include/mbedtls/block_cipher.h"
    "/tmp/pkgbuild/ot-br-posix-2026.08.0/third_party/openthread/repo/third_party/mbedtls/repo/include/mbedtls/build_info.h"
    "/tmp/pkgbuild/ot-br-posix-2026.08.0/third_party/openthread/repo/third_party/mbedtls/repo/include/mbedtls/camellia.h"
    "/tmp/pkgbuild/ot-br-posix-2026.08.0/third_party/openthread/repo/third_party/mbedtls/repo/include/mbedtls/ccm.h"
    "/tmp/pkgbuild/ot-br-posix-2026.08.0/third_party/openthread/repo/third_party/mbedtls/repo/include/mbedtls/chacha20.h"
    "/tmp/pkgbuild/ot-br-posix-2026.08.0/third_party/openthread/repo/third_party/mbedtls/repo/include/mbedtls/chachapoly.h"
    "/tmp/pkgbuild/ot-br-posix-2026.08.0/third_party/openthread/repo/third_party/mbedtls/repo/include/mbedtls/check_config.h"
    "/tmp/pkgbuild/ot-br-posix-2026.08.0/third_party/openthread/repo/third_party/mbedtls/repo/include/mbedtls/cipher.h"
    "/tmp/pkgbuild/ot-br-posix-2026.08.0/third_party/openthread/repo/third_party/mbedtls/repo/include/mbedtls/cmac.h"
    "/tmp/pkgbuild/ot-br-posix-2026.08.0/third_party/openthread/repo/third_party/mbedtls/repo/include/mbedtls/compat-2.x.h"
    "/tmp/pkgbuild/ot-br-posix-2026.08.0/third_party/openthread/repo/third_party/mbedtls/repo/include/mbedtls/config_adjust_legacy_crypto.h"
    "/tmp/pkgbuild/ot-br-posix-2026.08.0/third_party/openthread/repo/third_party/mbedtls/repo/include/mbedtls/config_adjust_legacy_from_psa.h"
    "/tmp/pkgbuild/ot-br-posix-2026.08.0/third_party/openthread/repo/third_party/mbedtls/repo/include/mbedtls/config_adjust_psa_from_legacy.h"
    "/tmp/pkgbuild/ot-br-posix-2026.08.0/third_party/openthread/repo/third_party/mbedtls/repo/include/mbedtls/config_adjust_psa_superset_legacy.h"
    "/tmp/pkgbuild/ot-br-posix-2026.08.0/third_party/openthread/repo/third_party/mbedtls/repo/include/mbedtls/config_adjust_ssl.h"
    "/tmp/pkgbuild/ot-br-posix-2026.08.0/third_party/openthread/repo/third_party/mbedtls/repo/include/mbedtls/config_adjust_x509.h"
    "/tmp/pkgbuild/ot-br-posix-2026.08.0/third_party/openthread/repo/third_party/mbedtls/repo/include/mbedtls/config_psa.h"
    "/tmp/pkgbuild/ot-br-posix-2026.08.0/third_party/openthread/repo/third_party/mbedtls/repo/include/mbedtls/constant_time.h"
    "/tmp/pkgbuild/ot-br-posix-2026.08.0/third_party/openthread/repo/third_party/mbedtls/repo/include/mbedtls/ctr_drbg.h"
    "/tmp/pkgbuild/ot-br-posix-2026.08.0/third_party/openthread/repo/third_party/mbedtls/repo/include/mbedtls/debug.h"
    "/tmp/pkgbuild/ot-br-posix-2026.08.0/third_party/openthread/repo/third_party/mbedtls/repo/include/mbedtls/des.h"
    "/tmp/pkgbuild/ot-br-posix-2026.08.0/third_party/openthread/repo/third_party/mbedtls/repo/include/mbedtls/dhm.h"
    "/tmp/pkgbuild/ot-br-posix-2026.08.0/third_party/openthread/repo/third_party/mbedtls/repo/include/mbedtls/ecdh.h"
    "/tmp/pkgbuild/ot-br-posix-2026.08.0/third_party/openthread/repo/third_party/mbedtls/repo/include/mbedtls/ecdsa.h"
    "/tmp/pkgbuild/ot-br-posix-2026.08.0/third_party/openthread/repo/third_party/mbedtls/repo/include/mbedtls/ecjpake.h"
    "/tmp/pkgbuild/ot-br-posix-2026.08.0/third_party/openthread/repo/third_party/mbedtls/repo/include/mbedtls/ecp.h"
    "/tmp/pkgbuild/ot-br-posix-2026.08.0/third_party/openthread/repo/third_party/mbedtls/repo/include/mbedtls/entropy.h"
    "/tmp/pkgbuild/ot-br-posix-2026.08.0/third_party/openthread/repo/third_party/mbedtls/repo/include/mbedtls/error.h"
    "/tmp/pkgbuild/ot-br-posix-2026.08.0/third_party/openthread/repo/third_party/mbedtls/repo/include/mbedtls/gcm.h"
    "/tmp/pkgbuild/ot-br-posix-2026.08.0/third_party/openthread/repo/third_party/mbedtls/repo/include/mbedtls/hkdf.h"
    "/tmp/pkgbuild/ot-br-posix-2026.08.0/third_party/openthread/repo/third_party/mbedtls/repo/include/mbedtls/hmac_drbg.h"
    "/tmp/pkgbuild/ot-br-posix-2026.08.0/third_party/openthread/repo/third_party/mbedtls/repo/include/mbedtls/lms.h"
    "/tmp/pkgbuild/ot-br-posix-2026.08.0/third_party/openthread/repo/third_party/mbedtls/repo/include/mbedtls/mbedtls_config.h"
    "/tmp/pkgbuild/ot-br-posix-2026.08.0/third_party/openthread/repo/third_party/mbedtls/repo/include/mbedtls/md.h"
    "/tmp/pkgbuild/ot-br-posix-2026.08.0/third_party/openthread/repo/third_party/mbedtls/repo/include/mbedtls/md5.h"
    "/tmp/pkgbuild/ot-br-posix-2026.08.0/third_party/openthread/repo/third_party/mbedtls/repo/include/mbedtls/memory_buffer_alloc.h"
    "/tmp/pkgbuild/ot-br-posix-2026.08.0/third_party/openthread/repo/third_party/mbedtls/repo/include/mbedtls/net_sockets.h"
    "/tmp/pkgbuild/ot-br-posix-2026.08.0/third_party/openthread/repo/third_party/mbedtls/repo/include/mbedtls/nist_kw.h"
    "/tmp/pkgbuild/ot-br-posix-2026.08.0/third_party/openthread/repo/third_party/mbedtls/repo/include/mbedtls/oid.h"
    "/tmp/pkgbuild/ot-br-posix-2026.08.0/third_party/openthread/repo/third_party/mbedtls/repo/include/mbedtls/pem.h"
    "/tmp/pkgbuild/ot-br-posix-2026.08.0/third_party/openthread/repo/third_party/mbedtls/repo/include/mbedtls/pk.h"
    "/tmp/pkgbuild/ot-br-posix-2026.08.0/third_party/openthread/repo/third_party/mbedtls/repo/include/mbedtls/pkcs12.h"
    "/tmp/pkgbuild/ot-br-posix-2026.08.0/third_party/openthread/repo/third_party/mbedtls/repo/include/mbedtls/pkcs5.h"
    "/tmp/pkgbuild/ot-br-posix-2026.08.0/third_party/openthread/repo/third_party/mbedtls/repo/include/mbedtls/pkcs7.h"
    "/tmp/pkgbuild/ot-br-posix-2026.08.0/third_party/openthread/repo/third_party/mbedtls/repo/include/mbedtls/platform.h"
    "/tmp/pkgbuild/ot-br-posix-2026.08.0/third_party/openthread/repo/third_party/mbedtls/repo/include/mbedtls/platform_time.h"
    "/tmp/pkgbuild/ot-br-posix-2026.08.0/third_party/openthread/repo/third_party/mbedtls/repo/include/mbedtls/platform_util.h"
    "/tmp/pkgbuild/ot-br-posix-2026.08.0/third_party/openthread/repo/third_party/mbedtls/repo/include/mbedtls/poly1305.h"
    "/tmp/pkgbuild/ot-br-posix-2026.08.0/third_party/openthread/repo/third_party/mbedtls/repo/include/mbedtls/private_access.h"
    "/tmp/pkgbuild/ot-br-posix-2026.08.0/third_party/openthread/repo/third_party/mbedtls/repo/include/mbedtls/psa_util.h"
    "/tmp/pkgbuild/ot-br-posix-2026.08.0/third_party/openthread/repo/third_party/mbedtls/repo/include/mbedtls/ripemd160.h"
    "/tmp/pkgbuild/ot-br-posix-2026.08.0/third_party/openthread/repo/third_party/mbedtls/repo/include/mbedtls/rsa.h"
    "/tmp/pkgbuild/ot-br-posix-2026.08.0/third_party/openthread/repo/third_party/mbedtls/repo/include/mbedtls/sha1.h"
    "/tmp/pkgbuild/ot-br-posix-2026.08.0/third_party/openthread/repo/third_party/mbedtls/repo/include/mbedtls/sha256.h"
    "/tmp/pkgbuild/ot-br-posix-2026.08.0/third_party/openthread/repo/third_party/mbedtls/repo/include/mbedtls/sha3.h"
    "/tmp/pkgbuild/ot-br-posix-2026.08.0/third_party/openthread/repo/third_party/mbedtls/repo/include/mbedtls/sha512.h"
    "/tmp/pkgbuild/ot-br-posix-2026.08.0/third_party/openthread/repo/third_party/mbedtls/repo/include/mbedtls/ssl.h"
    "/tmp/pkgbuild/ot-br-posix-2026.08.0/third_party/openthread/repo/third_party/mbedtls/repo/include/mbedtls/ssl_cache.h"
    "/tmp/pkgbuild/ot-br-posix-2026.08.0/third_party/openthread/repo/third_party/mbedtls/repo/include/mbedtls/ssl_ciphersuites.h"
    "/tmp/pkgbuild/ot-br-posix-2026.08.0/third_party/openthread/repo/third_party/mbedtls/repo/include/mbedtls/ssl_cookie.h"
    "/tmp/pkgbuild/ot-br-posix-2026.08.0/third_party/openthread/repo/third_party/mbedtls/repo/include/mbedtls/ssl_ticket.h"
    "/tmp/pkgbuild/ot-br-posix-2026.08.0/third_party/openthread/repo/third_party/mbedtls/repo/include/mbedtls/threading.h"
    "/tmp/pkgbuild/ot-br-posix-2026.08.0/third_party/openthread/repo/third_party/mbedtls/repo/include/mbedtls/timing.h"
    "/tmp/pkgbuild/ot-br-posix-2026.08.0/third_party/openthread/repo/third_party/mbedtls/repo/include/mbedtls/version.h"
    "/tmp/pkgbuild/ot-br-posix-2026.08.0/third_party/openthread/repo/third_party/mbedtls/repo/include/mbedtls/x509.h"
    "/tmp/pkgbuild/ot-br-posix-2026.08.0/third_party/openthread/repo/third_party/mbedtls/repo/include/mbedtls/x509_crl.h"
    "/tmp/pkgbuild/ot-br-posix-2026.08.0/third_party/openthread/repo/third_party/mbedtls/repo/include/mbedtls/x509_crt.h"
    "/tmp/pkgbuild/ot-br-posix-2026.08.0/third_party/openthread/repo/third_party/mbedtls/repo/include/mbedtls/x509_csr.h"
    )
endif()

if(CMAKE_INSTALL_COMPONENT STREQUAL "Unspecified" OR NOT CMAKE_INSTALL_COMPONENT)
  file(INSTALL DESTINATION "${CMAKE_INSTALL_PREFIX}/include/psa" TYPE FILE PERMISSIONS OWNER_READ OWNER_WRITE GROUP_READ WORLD_READ FILES
    "/tmp/pkgbuild/ot-br-posix-2026.08.0/third_party/openthread/repo/third_party/mbedtls/repo/include/psa/build_info.h"
    "/tmp/pkgbuild/ot-br-posix-2026.08.0/third_party/openthread/repo/third_party/mbedtls/repo/include/psa/crypto.h"
    "/tmp/pkgbuild/ot-br-posix-2026.08.0/third_party/openthread/repo/third_party/mbedtls/repo/include/psa/crypto_adjust_auto_enabled.h"
    "/tmp/pkgbuild/ot-br-posix-2026.08.0/third_party/openthread/repo/third_party/mbedtls/repo/include/psa/crypto_adjust_config_dependencies.h"
    "/tmp/pkgbuild/ot-br-posix-2026.08.0/third_party/openthread/repo/third_party/mbedtls/repo/include/psa/crypto_adjust_config_key_pair_types.h"
    "/tmp/pkgbuild/ot-br-posix-2026.08.0/third_party/openthread/repo/third_party/mbedtls/repo/include/psa/crypto_adjust_config_synonyms.h"
    "/tmp/pkgbuild/ot-br-posix-2026.08.0/third_party/openthread/repo/third_party/mbedtls/repo/include/psa/crypto_builtin_composites.h"
    "/tmp/pkgbuild/ot-br-posix-2026.08.0/third_party/openthread/repo/third_party/mbedtls/repo/include/psa/crypto_builtin_key_derivation.h"
    "/tmp/pkgbuild/ot-br-posix-2026.08.0/third_party/openthread/repo/third_party/mbedtls/repo/include/psa/crypto_builtin_primitives.h"
    "/tmp/pkgbuild/ot-br-posix-2026.08.0/third_party/openthread/repo/third_party/mbedtls/repo/include/psa/crypto_compat.h"
    "/tmp/pkgbuild/ot-br-posix-2026.08.0/third_party/openthread/repo/third_party/mbedtls/repo/include/psa/crypto_config.h"
    "/tmp/pkgbuild/ot-br-posix-2026.08.0/third_party/openthread/repo/third_party/mbedtls/repo/include/psa/crypto_driver_common.h"
    "/tmp/pkgbuild/ot-br-posix-2026.08.0/third_party/openthread/repo/third_party/mbedtls/repo/include/psa/crypto_driver_contexts_composites.h"
    "/tmp/pkgbuild/ot-br-posix-2026.08.0/third_party/openthread/repo/third_party/mbedtls/repo/include/psa/crypto_driver_contexts_key_derivation.h"
    "/tmp/pkgbuild/ot-br-posix-2026.08.0/third_party/openthread/repo/third_party/mbedtls/repo/include/psa/crypto_driver_contexts_primitives.h"
    "/tmp/pkgbuild/ot-br-posix-2026.08.0/third_party/openthread/repo/third_party/mbedtls/repo/include/psa/crypto_extra.h"
    "/tmp/pkgbuild/ot-br-posix-2026.08.0/third_party/openthread/repo/third_party/mbedtls/repo/include/psa/crypto_legacy.h"
    "/tmp/pkgbuild/ot-br-posix-2026.08.0/third_party/openthread/repo/third_party/mbedtls/repo/include/psa/crypto_platform.h"
    "/tmp/pkgbuild/ot-br-posix-2026.08.0/third_party/openthread/repo/third_party/mbedtls/repo/include/psa/crypto_se_driver.h"
    "/tmp/pkgbuild/ot-br-posix-2026.08.0/third_party/openthread/repo/third_party/mbedtls/repo/include/psa/crypto_sizes.h"
    "/tmp/pkgbuild/ot-br-posix-2026.08.0/third_party/openthread/repo/third_party/mbedtls/repo/include/psa/crypto_struct.h"
    "/tmp/pkgbuild/ot-br-posix-2026.08.0/third_party/openthread/repo/third_party/mbedtls/repo/include/psa/crypto_types.h"
    "/tmp/pkgbuild/ot-br-posix-2026.08.0/third_party/openthread/repo/third_party/mbedtls/repo/include/psa/crypto_values.h"
    )
endif()

string(REPLACE ";" "\n" CMAKE_INSTALL_MANIFEST_CONTENT
       "${CMAKE_INSTALL_MANIFEST_FILES}")
if(CMAKE_INSTALL_LOCAL_ONLY)
  file(WRITE "/tmp/pkgbuild/ot-br-posix-2026.08.0/build-test/third_party/openthread/repo/third_party/mbedtls/repo/include/install_local_manifest.txt"
     "${CMAKE_INSTALL_MANIFEST_CONTENT}")
endif()
